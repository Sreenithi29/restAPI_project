package com.example.demo.dto;

import com.example.demo.model.Product;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "Product Information Data Transfer Object")
public class ProductInfoDTO {

    @Schema(description = "Unique identifier of the product", example = "101")
    private Long id;

    @Schema(description = "Name of the product", example = "Organic Fertilizer")
    private String name;

    @Schema(description = "Price of the product", example = "299.99")
    private double price;

    public static ProductInfoDTO fromEntity(Product product) {
        ProductInfoDTO dto = new ProductInfoDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setPrice(product.getPrice());
        return dto;
    }
}
