package com.example.demo.service;
import com.example.demo.model.Nursery;
import com.example.demo.service.NurseryService;
import com.example.demo.repository.NurseryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NurseryService {

    @Autowired
    private NurseryRepository nurseryRepository;

    public Nursery createNursery(Nursery nursery) {
        return nurseryRepository.save(nursery);
    }

    public List<Nursery> getAllNurseries() {
        return (List<Nursery>) nurseryRepository.findAll();
    }

    public Page<Nursery> getNurseriesWithPagination(Pageable pageable) {
        return nurseryRepository.findAll(pageable);
    }

    public Nursery getNurseryById(Long id) {
        return nurseryRepository.findById(id).orElse(null);
    }

    public Nursery updateNursery(Long id, Nursery nurseryDetails) {
        return nurseryRepository.findById(id).map(existingNursery -> {
            existingNursery.setName(nurseryDetails.getName());
            existingNursery.setLocation(nurseryDetails.getLocation());
            return nurseryRepository.save(existingNursery);
        }).orElse(null);
    }

    public void deleteNursery(Long id) {
        nurseryRepository.deleteById(id);
    }
}
