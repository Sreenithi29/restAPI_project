// package com.example.demo.model;

// import jakarta.persistence.*;
// import java.time.LocalDateTime;

// import com.fasterxml.jackson.annotation.JsonBackReference;
// import com.fasterxml.jackson.annotation.JsonIgnore;

// @Entity
// @Table(name = "tracked_plants")
// public class TrackedPlant {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     private String status;

//     @ManyToOne
//     @JoinColumn(name = "user_id", nullable = false)
//     @JsonBackReference
//     private User user;

//     @ManyToOne
//     @JoinColumn(name = "plant_id", nullable = false)
//     private Plant plant;

//     private LocalDateTime trackingDate;

//     public Long getId() { return id; }
//     public void setId(Long id) { this.id = id; }

//     public String getStatus() { return status; }
//     public void setStatus(String status) { this.status = status; }

//     public User getUser() { return user; }
//     public void setUser(User user) { this.user = user; }

//     public Plant getPlant() { return plant; }
//     public void setPlant(Plant plant) { this.plant = plant; }

//     public LocalDateTime getTrackingDate() { return trackingDate; }
//     public void setTrackingDate(LocalDateTime trackingDate) { this.trackingDate = trackingDate; }
// }


package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name = "tracked_plants")
public class TrackedPlant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String status;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    private User user;

    @ManyToOne
    @JoinColumn(name = "plant_id", nullable = false)
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    private Plant plant;

    private LocalDateTime trackingDate;

    // Getters and Setters remain the same
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Plant getPlant() { return plant; }
    public void setPlant(Plant plant) { this.plant = plant; }

    public LocalDateTime getTrackingDate() { return trackingDate; }
    public void setTrackingDate(LocalDateTime trackingDate) { this.trackingDate = trackingDate; }
}