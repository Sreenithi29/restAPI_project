package com.example.demo.service;

import com.example.demo.model.TrackedPlant;
import com.example.demo.repository.TrackedPlantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrackedPlantService {

    @Autowired
    private TrackedPlantRepository trackedPlantRepository;

    public TrackedPlant createTrackedPlant(TrackedPlant trackedPlant) {
        return trackedPlantRepository.save(trackedPlant);
    }

    public List<TrackedPlant> getAllTrackedPlants() {
        return trackedPlantRepository.findAll();
    }

    public Page<TrackedPlant> getTrackedPlantsWithPagination(Pageable pageable) {
        return trackedPlantRepository.findAll(pageable);
    }

    public TrackedPlant getTrackedPlantById(Long id) {
        Optional<TrackedPlant> trackedPlant = trackedPlantRepository.findById(id);
        return trackedPlant.orElse(null);
    }

    public TrackedPlant updateTrackedPlant(Long id, TrackedPlant trackedPlantDetails) {
        Optional<TrackedPlant> optionalTrackedPlant = trackedPlantRepository.findById(id);
        if (optionalTrackedPlant.isPresent()) {
            TrackedPlant existingTrackedPlant = optionalTrackedPlant.get();
            existingTrackedPlant.setPlant(trackedPlantDetails.getPlant());
            existingTrackedPlant.setUser(trackedPlantDetails.getUser());
            existingTrackedPlant.setTrackingDate(trackedPlantDetails.getTrackingDate());
            return trackedPlantRepository.save(existingTrackedPlant);
        }
        return null;
    }

    public void deleteTrackedPlant(Long id) {
        trackedPlantRepository.deleteById(id);
    }
}
