package com.example.demo.dto;

import com.example.demo.model.Gardener;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "Gardener Info Data Transfer Object")
public class GardenerInfoDTO {

    @Schema(description = "Unique identifier of the gardener", example = "5")
    private Long id;

    @Schema(description = "Name of the gardener", example = "John Doe")
    private String name;

    @Schema(description = "Expertise of the gardener", example = "Landscaping")
    private String expertise;

    public static GardenerInfoDTO fromEntity(Gardener gardener) {
        GardenerInfoDTO dto = new GardenerInfoDTO();
        dto.setId(gardener.getId());
        dto.setName(gardener.getName());
        dto.setExpertise(gardener.getExpertise());
        return dto;
    }
}
