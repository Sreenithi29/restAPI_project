package com.example.demo.model;

import jakarta.persistence.*;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "plants")
public class Plant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String type;

    @ManyToMany(mappedBy = "plants", fetch = FetchType.LAZY)
    @JsonIgnore
    private List<User> users;
    
  

@OneToMany(mappedBy = "plant", cascade = CascadeType.ALL, orphanRemoval = true)
@JsonIgnore
private List<TrackedPlant> trackedPlants;



    public Plant() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<TrackedPlant> getTrackedPlants() {
        return trackedPlants;
    }

    public void setTrackedPlants(List<TrackedPlant> trackedPlants) {
        this.trackedPlants = trackedPlants;
    }
}


// package com.example.demo.model;

// import jakarta.persistence.*;
// import java.util.List;

// import com.fasterxml.jackson.annotation.JsonManagedReference;
// import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// @Entity
// @Table(name = "plants")
// @JsonIgnoreProperties(ignoreUnknown = true)
// public class Plant {
    
//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(nullable = false)
//     private String name;

//     @Column(nullable = false)
//     private String type;

//     @ManyToMany(fetch = FetchType.EAGER)  // Fetches User data eagerly
//     @JoinTable(
//         name = "user_plants",
//         joinColumns = @JoinColumn(name = "plant_id"),
//         inverseJoinColumns = @JoinColumn(name = "user_id")
//     )
//     @JsonManagedReference  // Handles bidirectional serialization
//     private List<User> users;

//     @OneToMany(mappedBy = "plant", cascade = CascadeType.ALL, orphanRemoval = true)
//     @JsonManagedReference
//     private List<TrackedPlant> trackedPlants;

//     // Default constructor
//     public Plant() {}

//     // Getters and Setters
//     public Long getId() { return id; }
//     public void setId(Long id) { this.id = id; }

//     public String getName() { return name; }
//     public void setName(String name) { this.name = name; }

//     public String getType() { return type; }
//     public void setType(String type) { this.type = type; }

//     public List<User> getUsers() { return users; }
//     public void setUsers(List<User> users) { this.users = users; }

//     public List<TrackedPlant> getTrackedPlants() { return trackedPlants; }
//     public void setTrackedPlants(List<TrackedPlant> trackedPlants) { this.trackedPlants = trackedPlants; }
// }
