package com.example.demo.controller;

import com.example.demo.dto.ProductDTO;
import com.example.demo.model.Product;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/gardener/{gardenerId}")
    public ResponseEntity<ProductDTO> createProduct(
            @PathVariable Long gardenerId,
            @RequestBody Product product) {
        Product createdProduct = productService.createProductForGardener(gardenerId, product);
        return ResponseEntity.status(HttpStatus.CREATED).body(ProductDTO.fromEntity(createdProduct));
    }

    // READ - Get all products
    @GetMapping
    public ResponseEntity<List<ProductDTO>> getAllProducts() {
        List<ProductDTO> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    // READ - Get all products with pagination
    @GetMapping("/paged")
    public ResponseEntity<Page<ProductDTO>> getAllProductsPaged(Pageable pageable) {
        Page<ProductDTO> products = productService.getAllProductsPaged(pageable);
        return ResponseEntity.ok(products);
    }

    // READ - Get product by ID
    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getProductById(@PathVariable Long id) {
        ProductDTO product = productService.getProductById(id);
        return ResponseEntity.ok(product);
    }

    // READ - Get products by gardener ID
    @GetMapping("/gardener/{gardenerId}")
    public ResponseEntity<List<ProductDTO>> getProductsByGardenerId(@PathVariable Long gardenerId) {
        List<ProductDTO> products = productService.getProductsByGardenerId(gardenerId);
        return ResponseEntity.ok(products);
    }

    // UPDATE - Update product
    @PutMapping("/{id}")
    public ResponseEntity<ProductDTO> updateProduct(
            @PathVariable Long id,
            @RequestBody Product productDetails) {
        ProductDTO updatedProduct = productService.updateProduct(id, productDetails);
        return ResponseEntity.ok(updatedProduct);
    }

    // DELETE - Delete product
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }
}