package com.example.demo.dto;

import com.example.demo.model.Gardener;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Schema(description = "Gardener Data Transfer Object")
public class GardenerDTO {

    @Schema(description = "Unique identifier of the gardener", example = "1")
    private Long id;

    @Schema(description = "Name of the gardener", example = "John Doe")
    private String name;

    @Schema(description = "Expertise of the gardener", example = "Organic Farming")
    private String expertise;

    @Schema(description = "List of products associated with the gardener")
    private List<ProductInfoDTO> products;

    public static GardenerDTO fromEntity(Gardener gardener) {
        GardenerDTO dto = new GardenerDTO();
        dto.setId(gardener.getId());
        dto.setName(gardener.getName());
        dto.setExpertise(gardener.getExpertise());

        if (gardener.getProducts() != null && !gardener.getProducts().isEmpty()) {
            dto.setProducts(gardener.getProducts().stream()
                .map(ProductInfoDTO::fromEntity)
                .collect(Collectors.toList()));
        }

        return dto;
    }
}
