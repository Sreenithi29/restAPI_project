package com.example.demo.controller;

import com.example.demo.dto.GardenerDTO;
import com.example.demo.model.Gardener;
import com.example.demo.service.GardenerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/gardeners")
public class GardenerController {

    @Autowired
    private GardenerService gardenerService;

    // CREATE
    @PostMapping
    public ResponseEntity<GardenerDTO> createGardener(@RequestBody Gardener gardener) {
        Gardener savedGardener = gardenerService.createGardener(gardener);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(GardenerDTO.fromEntity(savedGardener));
    }

    // READ (All)
    @GetMapping
    public ResponseEntity<List<GardenerDTO>> getAllGardeners() {
        List<GardenerDTO> gardeners = gardenerService.getAllGardeners().stream()
                .map(GardenerDTO::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(gardeners);
    }

    // READ (One)
    @GetMapping("/{id}")
    public ResponseEntity<GardenerDTO> getGardenerById(@PathVariable Long id) {
        return gardenerService.getGardenerById(id)
                .map(gardener -> ResponseEntity.ok(GardenerDTO.fromEntity(gardener)))
                .orElse(ResponseEntity.notFound().build());
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<GardenerDTO> updateGardener(
            @PathVariable Long id,
            @RequestBody Gardener gardenerDetails) {
        return gardenerService.updateGardener(id, gardenerDetails)
                .map(gardener -> ResponseEntity.ok(GardenerDTO.fromEntity(gardener)))
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGardener(@PathVariable Long id) {
        if (gardenerService.deleteGardener(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}