package com.example.demo.model;

import jakarta.persistence.*;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

  

@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
@JsonIgnore
private List<TrackedPlant> trackedPlants;


    
    @OneToOne(mappedBy = "user", cascade = CascadeType.PERSIST)
    @JsonIgnore
    private Nursery nursery;

    @ManyToMany
    @JoinTable(
        name = "user_plants",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "plant_id")
    )
    @JsonIgnore
    private List<Plant> plants;

    
    public User() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<TrackedPlant> getTrackedPlants() {
        return trackedPlants;
    }

    public void setTrackedPlants(List<TrackedPlant> trackedPlants) {
        this.trackedPlants = trackedPlants;
    }

    public Nursery getNursery() {
        return nursery;
    }

    public void setNursery(Nursery nursery) {
        this.nursery = nursery;
    }

    public List<Plant> getPlants() {
        return plants;
    }

    public void setPlants(List<Plant> plants) {
        this.plants = plants;
    }
}
// package com.example.demo.model;

// import jakarta.persistence.*;
// import java.util.List;

// import com.fasterxml.jackson.annotation.JsonBackReference;
// import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// @Entity
// @Table(name = "users")
// @JsonIgnoreProperties(ignoreUnknown = true)
// public class User {
    
//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(nullable = false)
//     private String name;

//     @Column(nullable = false, unique = true)
//     private String email;

//     @Column(nullable = false)
//     private String password;

//     @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
//     @JsonBackReference
//     private List<TrackedPlant> trackedPlants;
    
//     @OneToOne(mappedBy = "user", cascade = CascadeType.PERSIST)
//     @JsonBackReference
//     private Nursery nursery;

//     @ManyToMany(mappedBy = "users", fetch = FetchType.LAZY)
//     @JsonBackReference  // Avoids infinite recursion
//     private List<Plant> plants;

//     // Default constructor
//     public User() {}

//     // Getters and Setters
//     public Long getId() { return id; }
//     public void setId(Long id) { this.id = id; }

//     public String getName() { return name; }
//     public void setName(String name) { this.name = name; }

//     public String getEmail() { return email; }
//     public void setEmail(String email) { this.email = email; }

//     public String getPassword() { return password; }
//     public void setPassword(String password) { this.password = password; }

//     public List<TrackedPlant> getTrackedPlants() { return trackedPlants; }
//     public void setTrackedPlants(List<TrackedPlant> trackedPlants) { this.trackedPlants = trackedPlants; }

//     public Nursery getNursery() { return nursery; }
//     public void setNursery(Nursery nursery) { this.nursery = nursery; }

//     public List<Plant> getPlants() { return plants; }
//     public void setPlants(List<Plant> plants) { this.plants = plants; }
// }

