package com.example.demo.service;

import com.example.demo.model.Gardener;
import com.example.demo.repository.GardenerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GardenerService {

    @Autowired
    private GardenerRepository gardenerRepository;

    public Gardener createGardener(Gardener gardener) {
        return gardenerRepository.save(gardener);
    }

    public List<Gardener> getAllGardeners() {
        return gardenerRepository.findAll();
    }

    public Optional<Gardener> getGardenerById(Long id) {
        return gardenerRepository.findById(id);
    }

    public Optional<Gardener> updateGardener(Long id, Gardener gardenerDetails) {
        return gardenerRepository.findById(id)
                .map(existingGardener -> {
                    existingGardener.setName(gardenerDetails.getName());
                    existingGardener.setExpertise(gardenerDetails.getExpertise());
                    return gardenerRepository.save(existingGardener);
                });
    }

    public boolean deleteGardener(Long id) {
        if (gardenerRepository.existsById(id)) {
            gardenerRepository.deleteById(id);
            return true;
        }
        return false;
    }
}