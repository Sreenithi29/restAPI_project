package com.example.demo.service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Plant;
import com.example.demo.repository.PlantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PlantService {

    @Autowired
    private PlantRepository plantRepository;

    public Plant createPlant(Plant plant) {
        return plantRepository.save(plant);
    }

    public List<Plant> getAllPlants() {
        return plantRepository.findAll();
    }

    public Page<Plant> getPlantsWithPagination(Pageable pageable) {
        return plantRepository.findAll(pageable);
    }

    public Plant getPlantById(Long id) {
        return plantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with id: " + id));
    }

    // Custom query methods
    public List<Plant> getPlantsByName(String name) {
        return plantRepository.findByName(name);
    }

    public List<Plant> searchPlantsByName(String name) {
        return plantRepository.findByNameContainingIgnoreCase(name);
    }

    public List<Plant> getPlantsByType(String type) {
        return plantRepository.findByType(type);
    }

    public Plant updatePlant(Long id, Plant plantDetails) {
        Plant plant = plantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with id: " + id));
        
        plant.setName(plantDetails.getName());
        plant.setType(plantDetails.getType());
        
        return plantRepository.save(plant);
    }

    public void deletePlant(Long id) {
        Plant plant = plantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with id: " + id));
        plantRepository.delete(plant);
    }
}