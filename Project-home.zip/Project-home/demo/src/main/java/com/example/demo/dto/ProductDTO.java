package com.example.demo.dto;

import com.example.demo.model.Product;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "Product Data Transfer Object")
public class ProductDTO {
    
    @Schema(description = "Unique identifier of the product", example = "101")
    private Long id;

    @Schema(description = "Name of the product", example = "Organic Fertilizer")
    private String name;

    @Schema(description = "Price of the product", example = "299.99")
    private double price;

    @Schema(description = "Gardener details associated with the product")
    private GardenerInfoDTO gardener;

    public static ProductDTO fromEntity(Product product) {
        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setPrice(product.getPrice());

        if (product.getGardener() != null) {
            dto.setGardener(GardenerInfoDTO.fromEntity(product.getGardener()));
        }

        return dto;
    }
}




// package com.example.demo.dto;

// import com.example.demo.model.Gardener;
// import lombok.Data;
// import com.example.demo.model.*;
// import com.example.demo.dto.*;

// @Data
// public class ProductDTO {
//     private Long id;
//     private String name;
//     private double price;
//     private GardenerInfoDTO gardener;

//     public static ProductDTO fromEntity(Product product) {
//         ProductDTO dto = new ProductDTO();
//         dto.setId(product.getId());
//         dto.setName(product.getName());
//         dto.setPrice(product.getPrice());
        
//         if (product.getGardener() != null) {
//             dto.setGardener(GardenerInfoDTO.fromEntity(product.getGardener()));
//         }
        
//         return dto;
//     }
// }

// @Data
// class GardenerInfoDTO {
//     private Long id;
//     private String name;
//     private String expertise;

//     public static GardenerInfoDTO fromEntity(Gardener gardener) {
//         GardenerInfoDTO dto = new GardenerInfoDTO();
//         dto.setId(gardener.getId());
//         dto.setName(gardener.getName());
//         dto.setExpertise(gardener.getExpertise());
//         return dto;
//     }
// }