package com.example.demo.controller;


import com.example.demo.model.TrackedPlant;
import com.example.demo.service.TrackedPlantService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/trackedplants")
public class TrackedPlantController {

    @Autowired
    private TrackedPlantService trackedPlantService;
@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TrackedPlant> createTrackedPlant(@RequestBody TrackedPlant trackedPlant) {
        TrackedPlant saved = trackedPlantService.createTrackedPlant(trackedPlant);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }
    
    @GetMapping
    public List<TrackedPlant> getAllTrackedPlants() {
        return trackedPlantService.getAllTrackedPlants();
    }

    @GetMapping("/paged")
    public Page<TrackedPlant> getTrackedPlantsWithPagination(Pageable pageable) {
        return trackedPlantService.getTrackedPlantsWithPagination(pageable);
    }

    @GetMapping("/{id}")
    public TrackedPlant getTrackedPlantById(@PathVariable Long id) {
        return trackedPlantService.getTrackedPlantById(id);
    }

    @PutMapping("/{id}")
    public TrackedPlant updateTrackedPlant(@PathVariable Long id, @RequestBody TrackedPlant trackedPlant) {
        return trackedPlantService.updateTrackedPlant(id, trackedPlant);
    }

    @DeleteMapping("/{id}")
    public void deleteTrackedPlant(@PathVariable Long id) {
        trackedPlantService.deleteTrackedPlant(id);
    }
}
