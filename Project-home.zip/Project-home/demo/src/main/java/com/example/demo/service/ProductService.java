package com.example.demo.service;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.dto.*;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Service
@Transactional
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private GardenerRepository gardenerRepository;

    // CREATE
    public Product createProductForGardener(Long gardenerId, Product product) {
        Gardener gardener = gardenerRepository.findById(gardenerId)
                .orElseThrow(() -> new ResourceNotFoundException("Gardener not found"));
        
        gardener.addProduct(product);
        return productRepository.save(product); // Return the entity, not DTO
    }
    // READ - All products
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll().stream()
                .map(ProductDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // READ - All products paged
    public Page<ProductDTO> getAllProductsPaged(Pageable pageable) {
        return productRepository.findAll(pageable)
                .map(ProductDTO::fromEntity);
    }

    // READ - Single product
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        return ProductDTO.fromEntity(product);
    }

    // READ - Products by gardener
    public List<ProductDTO> getProductsByGardenerId(Long gardenerId) {
        return productRepository.findByGardenerId(gardenerId).stream()
                .map(ProductDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // UPDATE
    public ProductDTO updateProduct(Long id, Product productDetails) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        
        product.setName(productDetails.getName());
        product.setPrice(productDetails.getPrice());
        
        if (productDetails.getGardener() != null && 
            !productDetails.getGardener().getId().equals(product.getGardener().getId())) {
            Gardener newGardener = gardenerRepository.findById(productDetails.getGardener().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Gardener not found"));
            product.getGardener().removeProduct(product);
            newGardener.addProduct(product);
        }
        
        return ProductDTO.fromEntity(product);
    }

    // DELETE
    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        
        if (product.getGardener() != null) {
            product.getGardener().removeProduct(product);
        }
        productRepository.delete(product);
    }
}