package com.example.demo.controller;

import com.example.demo.model.Plant;
import com.example.demo.service.PlantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

@RequestMapping("/api/plants")
public class PlantController {

    @Autowired
    private PlantService plantService;

    @PostMapping
    public ResponseEntity<Plant> createPlant(@RequestBody Plant plant) {
        Plant createdPlant = plantService.createPlant(plant);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPlant);
    }
    

    @GetMapping
    public ResponseEntity<List<Plant>> getAllPlants() {
        List<Plant> plants = plantService.getAllPlants();
        return ResponseEntity.ok(plants);
    }

    @GetMapping("/paged")
    public ResponseEntity<Page<Plant>> getPlantsWithPagination(Pageable pageable) {
        Page<Plant> plants = plantService.getPlantsWithPagination(pageable);
        return ResponseEntity.ok(plants);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Plant> getPlantById(@PathVariable Long id) {
        Plant plant = plantService.getPlantById(id);
        return ResponseEntity.ok(plant);
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<List<Plant>> getPlantsByName(@PathVariable String name) {
        List<Plant> plants = plantService.getPlantsByName(name);
        return ResponseEntity.ok(plants);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Plant>> searchPlantsByName(@RequestParam String name) {
        List<Plant> plants = plantService.searchPlantsByName(name);
        return ResponseEntity.ok(plants);
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<List<Plant>> getPlantsByType(@PathVariable String type) {
        List<Plant> plants = plantService.getPlantsByType(type);
        return ResponseEntity.ok(plants);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Plant> updatePlant(@PathVariable Long id, @RequestBody Plant plantDetails) {
        Plant updatedPlant = plantService.updatePlant(id, plantDetails);
        return ResponseEntity.ok(updatedPlant);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlant(@PathVariable Long id) {
        plantService.deletePlant(id);
        return ResponseEntity.noContent().build();
    }
}