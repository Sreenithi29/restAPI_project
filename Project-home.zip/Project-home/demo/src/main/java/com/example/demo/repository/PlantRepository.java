package com.example.demo.repository;

import com.example.demo.model.Plant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlantRepository extends JpaRepository<Plant, Long> {
    
    // Find plants by name (exact match)
    @Query("SELECT p FROM Plant p WHERE p.name = :name")
    List<Plant> findByName(@Param("name") String name);
    
    // Find plants by name containing string (case-insensitive)
    @Query("SELECT p FROM Plant p WHERE LOWER(p.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Plant> findByNameContainingIgnoreCase(@Param("name") String name);
    
    // Find plants by type
    @Query("SELECT p FROM Plant p WHERE p.type = :type")
    List<Plant> findByType(@Param("type") String type);
}