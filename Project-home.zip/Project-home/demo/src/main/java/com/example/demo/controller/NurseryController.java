package com.example.demo.controller;

import com.example.demo.model.Nursery;
import com.example.demo.service.NurseryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/nurseries")
public class NurseryController {

    @Autowired
    private NurseryService nurseryService;

    @PostMapping
    public Nursery createNursery(@RequestBody Nursery nursery) {
        return nurseryService.createNursery(nursery);
    }

    @GetMapping
    public List<Nursery> getAllNurseries() {
        return nurseryService.getAllNurseries();
    }

    @GetMapping("/paged")
    public Page<Nursery> getNurseriesWithPagination(Pageable pageable) {
        return nurseryService.getNurseriesWithPagination(pageable);
    }

    @GetMapping("/{id}")
    public Nursery getNurseryById(@PathVariable Long id) {
        return nurseryService.getNurseryById(id);
    }

    @PutMapping("/{id}")
    public Nursery updateNursery(@PathVariable Long id, @RequestBody Nursery nursery) {
        return nurseryService.updateNursery(id, nursery);
    }

    @DeleteMapping("/{id}")
    public void deleteNursery(@PathVariable Long id) {
        nurseryService.deleteNursery(id);
    }
}