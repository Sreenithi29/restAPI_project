package com.example.demo.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.*;
import java.util.*;

@Entity
@Table(name = "gardeners")
public class Gardener {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String expertise;

    @OneToMany(mappedBy = "gardener", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("gardener")
    private List<Product> products = new ArrayList<>();

    // Constructors
    public Gardener() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getExpertise() { return expertise; }
    public void setExpertise(String expertise) { this.expertise = expertise; }
    public List<Product> getProducts() { return products; }
    
    public void setProducts(List<Product> products) {
        this.products.clear();
        if (products != null) {
            products.forEach(this::addProduct);
        }
    }
    
    public void addProduct(Product product) {
        products.add(product);
        product.setGardener(this);
    }
    
    public void removeProduct(Product product) {
        products.remove(product);
        product.setGardener(null);
    }
}